/**
 * @file null.h
 *
 * $Id: null.h 1986 2009-08-12 00:33:27Z mschul $
 */
/* Embedded Xinu, Copyright (C) 2009.  All rights reserved. */


/* File automatically included by xinu.conf system for null struct dentry */
