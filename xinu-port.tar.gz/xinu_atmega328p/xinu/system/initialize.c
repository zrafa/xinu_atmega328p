/* initialize.c - nulluser, sysinit */

/* Handle system initialization and become the null process */

#include <xinu.h>
#include <string.h>

#define VERSION "0.1"

extern	void	_start(void);	/* start of Xinu code */
extern	void	*_end;		/* end of Xinu code */

/* Function prototypes */

extern	void main(void);	/* main is the first process created	*/
extern	void xdone(void);	/* system "shutdown" procedure		*/
static	void sysinit(void);	/* initializes system structures	*/

/* Declarations of major kernel variables */

struct	procent	proctab[NPROC];	/* Process table			*/
struct	sentry	semtab[NSEM];	/* Semaphore table			*/
struct	memblk	memlist;	/* List of free memory blocks		*/

/* Active system status */

int32	prcount;		/* Total number of live processes	*/
pid32	currpid;		/* ID of currently executing process	*/

/* Memory bounds set by start.S */

void	*minheap;		/* start of heap			*/
void	*maxheap;		/* highest valid memory address		*/

/*
char *strncpy(char *s1, const char *s2, int n)
{
    register int i;
    register char *os1;

    os1 = s1;
    for (i = 0; i < n; i++)
    {
        if (((*s1++) = (*s2++)) == '\0')
        {
            while (++i < n)
            {
                *s1++ = '\0';
            }
            return os1;
        }
    }
    return os1;
}
*/

/*------------------------------------------------------------------------
 * nulluser - initialize the system and become the null process
 *
 * Note: execution begins here after the C run-time environment has been
 * established.  Interrupts are initially DISABLED, and must eventually
 * be enabled explicitly.  The code turns itself into the null process
 * after initialization.  Because it must always remain ready to execute,
 * the null process cannot execute code that might cause it to be
 * suspended, wait for a semaphore, put to sleep, or exit.  In
 * particular, the code must not perform I/O except for polled versions
 * such as kprintf.
 *------------------------------------------------------------------------
 */

	char s3[80];
	char *s4;
void	nulluser(void)
{
	kprintf("\n\r%s\n\n\r", VERSION);

	sysinit();

	/* Output Xinu memory layout */

	kprintf("%10d bytes physical memory.\r\n",
	// RAFA	(uint32)maxheap - (uint32)addressp2k(0));
		(uint32)maxheap - (uint32)minheap);
	kprintf("           [0x%08X to 0x%08X]\r\n",
	// RAFA	(uint32)addressp2k(0), (uint32)maxheap - 1);
		(uint32)minheap, (uint32)maxheap - 1);
	// RAFA kprintf("%10d bytes reserved system area.\r\n",
	// RAFA 	(uint32)_start - (uint32)addressp2k(0));
	// RAFA kprintf("           [0x%08X to 0x%08X]\r\n",
	// RAFA 	(uint32)addressp2k(0), (uint32)_start - 1);
	// RAFA kprintf("%10d bytes Xinu code.\r\n",
	// RAFA 	(uint32)&_end - (uint32)_start);
	// RAFA kprintf("           [0x%08X to 0x%08X]\r\n",
	// RAFA 	(uint32)_start, (uint32)&_end - 1);
	// RAFA kprintf("%10d bytes stack space.\r\n",
	// RAFA 	(uint32)minheap - (uint32)&_end);
	// RAFA kprintf("           [0x%08X to 0x%08X]\r\n",
	// RAFA 	(uint32)&_end, (uint32)minheap - 1);
	kprintf("%10d bytes heap space.\r\n",
		(uint32)maxheap - (uint32)minheap);
	kprintf("           [0x%08X to 0x%08X]\r\n\r\n",
		(uint32)minheap, (uint32)maxheap - 1);

	// RAFA
	char hola[] ="hola mundo! \n";
	// char s3[80] = "mundo jurasic";
	char *s = getmem(16);
	kprintf("    direccion asignada       [0x%08X]\r\n\r\n", (uint32)s);
	char * s2 = (char *)getmem(16);
	kprintf("    direccion asignada 2      [0x%08X]\r\n\r\n", (uint32)s2);
	s4=strncpy(s3, "mundo cruel", 11);
	kprintf("s3:%s\r\n", s3);
	kprintf("s4:%s\r\n", s4);
	strncpy(s2, hola, 13);
	kprintf("original en memoria:%s\r\n", hola);
	kprintf("copia en memoria:%s\r\n", s2);
	kprintf("direccion original en memoria:%8x\r\n", (uint32)hola);
	kprintf("direccion copia en memoria:%8x\r\n", (uint32)s2);
	while (s2<0x1000) {
		s2 = (char *)getmem(16);
		kprintf("direccion s2:%8x ", (uint32)s2);
		strncpy(s2, hola, 14);
		kprintf("cadena s2:%s\r\n", s2);
	}
	/* Enable interrupts */

	// RAFA enable();

	/* Create a process to execute function main() */

	// RAFA resume(create
        // RAFA   ((void *)main, INITSTK, INITPRIO, "Main process", 0, NULL));

	/* Become the Null process (i.e., guarantee that the CPU has	*/
	/*  something to run when no other process is ready to execute)	*/

	while (TRUE) {
		;		/* do nothing */
	}
}

/*------------------------------------------------------------------------
 *
 * sysinit - intialize all Xinu data structures and devices
 *
 *------------------------------------------------------------------------
 */

static	void	sysinit(void)
{
	int32	i;
	struct	procent	*prptr;		/* ptr to process table entry	*/
	struct	sentry	*semptr;	/* prr to semaphore table entry	*/
	struct	memblk	*memptr;	/* ptr to memory block		*/

	/* Initialize system variables */

	/* Count the Null process as the first process in the system */

	prcount = 1;

	/* Scheduling is not currently blocked */

	// RAFA Defer.ndefers = 0;

	/* Initialize the free memory list */

	// RAFA maxheap = (void *)addressp2k(MAXADDR);
	maxheap = (void *)0x00700;
	minheap = (void *)0x00400; // RAFA

	memlist.mnext = (struct memblk *)minheap;

	/* Overlay memblk structure on free memory and set fields */

	memptr = (struct memblk *)minheap;
	memptr->mnext = NULL;
	memptr->mlength = memlist.mlength = (uint32)(maxheap - minheap);

	/* Initialize process table entries free */

	for (i = 0; i < NPROC; i++) {
		prptr = &proctab[i];
		prptr->prstate = PR_FREE;
		prptr->prname[0] = NULLCH;
		prptr->prstkbase = NULL;
		prptr->prprio = 0;
	}

	/* Initialize the Null process entry */

	prptr = &proctab[NULLPROC];
	prptr->prstate = PR_CURR;
	prptr->prprio = 0;
	strncpy(prptr->prname, "prnull", 7);
	prptr->prstkbase = minheap;
	prptr->prstklen = NULLSTK;
	prptr->prstkptr = 0;
	currpid = NULLPROC;

	/* Initialize semaphores */

	// RAFA for (i = 0; i < NSEM; i++) {
	// RAFA 	semptr = &semtab[i];
	// RAFA 	semptr->sstate = S_FREE;
	// RAFA 	semptr->scount = 0;
	// RAFA 	semptr->squeue = newqueue();
	// RAFA }

	/* Initialize buffer pools */

	// RAFA bufinit();

	/* Create a ready list for processes */

	// RAFA readylist = newqueue();

	/* Initialize real time clock */

	// RAFA clkinit();

	/* Initialize non-volative RAM storage */

	// RAFA nvramInit();

	/* Initialize devices */

	// RAFA for (i = 0; i < NDEVS; i++) {
	// RAFA 	init(i);
	// RAFA }
	return;
}
