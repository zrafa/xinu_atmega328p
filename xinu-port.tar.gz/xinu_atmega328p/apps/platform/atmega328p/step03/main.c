
int kprintf(char *fmt, ...);
int main()
{

	kprintf("Hello world!\r\n");

	return 0;
}

