# xinu_atmega328p
xinu OS port for avr atmega328p

Original sources:  https://xinu.cs.purdue.edu/files/Xinu-code-MIPS.tar.gz


